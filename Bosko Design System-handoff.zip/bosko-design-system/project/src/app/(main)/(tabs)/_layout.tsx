import { Stack, Tabs } from 'expo-router'
import { ExtendedStackNavigationOptions } from 'expo-router/build/layouts/StackClient'
import { LucideLibraryBig, LucideUserCircle2 } from 'lucide-react-native'

import { Icon } from '@/components/ui/icon'

const SCREEN_OPTIONS = {
  title: '',
  headerShown: false,
} as ExtendedStackNavigationOptions

export default function TabLayout() {
  return (
    <>
      <Stack.Screen options={SCREEN_OPTIONS} />
      <Tabs>
        <Tabs.Screen
          name="bookshelf/index"
          options={{
            tabBarLabel: 'Estante',
            title: 'Estante',
            tabBarIcon: ({ color }) => <Icon as={LucideLibraryBig} color={color} size={24} />,
          }}
        />

        <Tabs.Screen
          name="profile/index"
          options={{
            tabBarLabel: 'Perfil',
            title: 'Perfil',
            tabBarIcon: ({ color }) => <Icon as={LucideUserCircle2} color={color} size={24} />,
          }}
        />
      </Tabs>
    </>
  )
}
