import { Stack } from 'expo-router'
import { ExtendedStackNavigationOptions } from 'expo-router/build/layouts/StackClient'
import { View } from 'react-native'

import { useGetCurrentUserProfile } from '@/modules/auth/query'

import { AdCard } from '@/components/feature/ads/ad-card'
import { ContinueReadingCard } from '@/components/feature/profile/continue-reading-card'
import { ProfileHeader } from '@/components/feature/profile/header'
import { SettingsButton } from '@/components/kit/settings-button'

const SCREEN_OPTIONS = {
  title: 'Perfil',
  headerRight: () => <SettingsButton />,
} as ExtendedStackNavigationOptions

export default function ProfileScreen() {
  const { data: user } = useGetCurrentUserProfile()

  return (
    <>
      <Stack.Screen options={{ ...SCREEN_OPTIONS, title: user?.username }} />

      {user && (
        <View className="gap-6 p-4">
          <ProfileHeader user={user} />
          <ContinueReadingCard />
          <View className="items-center">
            <AdCard />
          </View>
        </View>
      )}
    </>
  )
}
