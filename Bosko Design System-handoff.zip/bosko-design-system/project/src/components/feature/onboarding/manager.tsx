import { useRouter } from 'expo-router'
import { LucideLoader2 } from 'lucide-react-native'
import { useState } from 'react'
import { useFormContext } from 'react-hook-form'
import { View } from 'react-native'

import { userKeys } from '@/core/storage/keys'
import { userStorage } from '@/core/storage/mmkv'

import { signIn, signUp } from '@/adapters/api/auth'

import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icon'
import { Progress } from '@/components/ui/progress'
import { Text } from '@/components/ui/text'

import { OnboardingFormData } from './schema'
import { ONBOARDING_STEPS } from './steps'

export function OnboardingManager() {
  const router = useRouter()
  const [index, setIndex] = useState(0)
  const { trigger, handleSubmit, formState } = useFormContext<OnboardingFormData>()

  const currentStep = ONBOARDING_STEPS[index]
  const StepComponent = currentStep.component
  const isLastStep = index === ONBOARDING_STEPS.length - 1

  const progress = ((index + 1) / ONBOARDING_STEPS.length) * 100

  const register = async (data: OnboardingFormData) => {
    // TODO - Upload avatar if exists and get the URL to send to the backend

    await signUp(data)

    const response = await signIn({
      email: data.email,
      password: data.password,
    })

    userStorage.set(userKeys.ACCESS_TOKEN, response.accessToken)
    userStorage.set(userKeys.REFRESH_TOKEN, response.refreshToken)
    userStorage.set(
      userKeys.PROFILE,
      JSON.stringify({
        id: response.id,
        email: response.email,
        displayName: data.displayName,
        username: data.username,
      })
    )

    router.dismissAll()
    router.replace('/profile')
  }

  const handleNext = async () => {
    const isValid = await trigger(ONBOARDING_STEPS[index].fields)

    if (!isValid) return

    if (index < ONBOARDING_STEPS.length - 1) {
      setIndex(prev => prev + 1)
    } else {
      await handleSubmit(register)()
    }
  }

  const handleBack = () => {
    if (index > 0) setIndex(prev => prev - 1)
  }

  return (
    <View className="pb-safe-offset-4 flex-1 gap-8 bg-background p-4">
      <View className="gap-2">
        <Progress value={progress} indicatorClassName="bg-primary" />
        <Text className="text-right text-xs font-medium text-muted-foreground">
          Passo {index + 1} de {ONBOARDING_STEPS.length}
        </Text>
      </View>

      <View className="flex-1">
        <StepComponent />
      </View>

      <View className="flex-row gap-4">
        {index > 0 && (
          <Button variant="outline" onPress={handleBack}>
            <Text>Voltar</Text>
          </Button>
        )}

        <Button className={index > 0 ? 'flex-[2]' : 'flex-1'} onPress={handleNext} disabled={formState.isSubmitting}>
          {!formState.isSubmitting && <Text className="font-bold">{isLastStep ? 'Finalizar' : 'Próximo'}</Text>}

          {formState.isSubmitting && (
            <Icon as={LucideLoader2} className="animate-spin text-primary-foreground" size={16} />
          )}
        </Button>
      </View>
    </View>
  )
}
