import { router, type Href } from 'expo-router'
import { LucideHardDriveDownload, LucideMoreVertical } from 'lucide-react-native'
import { Alert, Image, Pressable, View } from 'react-native'

import { useLocalBooksStore, type LocalBook } from '@/core/store/local-books-store'
import { useReaderProgressStore } from '@/core/store/reader-progress-store'

import { deleteLocalBookFiles } from '@/adapters/local/epub-metadata'

import { Icon } from '@/components/ui/icon'
import { Text } from '@/components/ui/text'

interface LocalBookCardProps {
  book: LocalBook
}

export function LocalBookCard({ book }: LocalBookCardProps) {
  const removeBook = useLocalBooksStore(s => s.removeBook)
  const updateBook = useLocalBooksStore(s => s.updateBook)
  const localProgress = useReaderProgressStore(s => s.history[book.id])
  const progress = localProgress?.percentage ? localProgress.percentage * 100 : 0

  const handlePress = () => {
    router.push({ pathname: '/reader/[bookId]', params: { bookId: book.id } })
  }

  const handleLongPress = () => {
    Alert.alert(book.title, undefined, [
      {
        text: 'Editar',
        onPress: () => router.push({ pathname: '/local-books/edit', params: { bookId: book.id } } as unknown as Href),
      },
      {
        text: 'Mudar status',
        onPress: () => showStatusPicker(),
      },
      {
        text: 'Remover',
        style: 'destructive',
        onPress: () => confirmRemove(),
      },
      { text: 'Cancelar', style: 'cancel' },
    ])
  }

  const showStatusPicker = () => {
    const STATUS_LABELS: Record<string, string> = {
      TO_READ: 'Para Ler',
      READING: 'Lendo',
      READ: 'Lidos',
    }
    const options: ('TO_READ' | 'READING' | 'READ')[] = ['TO_READ', 'READING', 'READ']

    Alert.alert('Alterar status', `Status atual: ${STATUS_LABELS[book.status]}`, [
      ...options
        .filter(s => s !== book.status)
        .map(s => ({
          text: STATUS_LABELS[s],
          onPress: () => updateBook({ id: book.id, updates: { status: s } }),
        })),
      { text: 'Cancelar', style: 'cancel' as const },
    ])
  }

  const confirmRemove = () => {
    Alert.alert(
      'Remover livro',
      `Tem certeza que deseja remover "${book.title}" da sua estante? O arquivo será excluído permanentemente.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Remover',
          style: 'destructive',
          onPress: async () => {
            removeBook({ id: book.id })
            await deleteLocalBookFiles({ epubPath: book.epubPath, coverPath: book.coverPath })
          },
        },
      ]
    )
  }

  const coverUri = book.coverPath ? `file://${book.coverPath}` : undefined

  return (
    <Pressable className="flex-1 gap-3 active:opacity-80" onPress={handlePress} onLongPress={handleLongPress}>
      <View className="aspect-[2/3] w-full overflow-hidden rounded-2xl border border-border/50 bg-secondary shadow-md">
        {coverUri && <Image source={{ uri: coverUri }} className="h-full w-full" resizeMode="cover" />}

        {!coverUri && (
          <View className="flex-1 items-center justify-center bg-secondary">
            <Icon as={LucideMoreVertical} size={32} className="color-muted-foreground" />
          </View>
        )}

        <View className="absolute right-2 top-2 h-6 w-6 items-center justify-center rounded-full bg-background/80">
          <Icon as={LucideHardDriveDownload} size={13} className="color-foreground" />
        </View>

        {book.status === 'READING' && progress > 0 && (
          <View className="absolute bottom-0 left-0 right-0 h-1 bg-black/20">
            <View className="h-full bg-primary" style={{ width: `${Math.min(progress, 100)}%` }} />
          </View>
        )}
      </View>

      <View className="gap-0.5 px-1">
        <Text numberOfLines={1} className="text-base font-bold leading-tight text-foreground">
          {book.title}
        </Text>

        <Text numberOfLines={1} className="text-xs font-medium uppercase tracking-tight text-muted-foreground">
          {book.status === 'READING' &&
            localProgress?.location != null &&
            `Pág. ${localProgress.location} de ${localProgress.totalLocations}`}
          {!(book.status === 'READING' && localProgress) && (book.author || 'Autor desconhecido')}
        </Text>
      </View>
    </Pressable>
  )
}
