import { ChevronRight, LucideIcon } from 'lucide-react-native'
import { Pressable, View } from 'react-native'

import { cn } from '@/components/lib/utils'
import { Icon } from '@/components/ui/icon'
import { Text } from '@/components/ui/text'

interface SettingsItemProps {
  label: string;
  icon: LucideIcon;
  onPress: () => void;
  variant?: 'default' | 'danger';
  showChevron?: boolean;
}

export const SettingsItem = ({
  label,
  icon,
  onPress,
  variant = 'default',
  showChevron = true,
}: SettingsItemProps) => {
  return (
    <Pressable
      onPress={onPress}
      className="flex-row items-center justify-between p-4 bg-secondary/10 rounded-2xl active:opacity-70"
    >
      <View className="flex-row items-center gap-4">
        <View className={cn(
          "w-10 h-10 items-center justify-center rounded-xl bg-primary/10",
          variant === 'danger' && "bg-red-500/10"
        )}>
          <Icon
            as={icon}
            className={cn(
              "size-5 text-primary",
              variant === 'danger' && "text-red-500"
            )}
          />
        </View>
        <Text className={cn(
          "text-base font-medium text-foreground",
          variant === 'danger' && "text-red-500"
        )}>
          {label}
        </Text>
      </View>

      {showChevron && variant !== 'danger' && (
        <Icon as={ChevronRight} size={20} className="text-muted-foreground/50" />
      )}
    </Pressable>
  )
}