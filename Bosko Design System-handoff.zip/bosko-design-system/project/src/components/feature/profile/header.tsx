import { View } from 'react-native'

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Text } from '@/components/ui/text'

interface Props {
  user: {
    displayName: string
    avatarUrl: string | null
  }
}

export const ProfileHeader = ({ user }: Props) => {
  return (
    <View className="flex-row items-center gap-4 py-2">
      <Avatar alt="Foto de Perfil" className="size-16 rounded-2xl">
        <AvatarImage source={{ uri: user?.avatarUrl ?? undefined }} />
        <AvatarFallback className="rounded-2xl bg-secondary/40">
          <Text className="text-2xl font-bold">{user?.displayName[0]}</Text>
        </AvatarFallback>
      </Avatar>

      <View className="flex-1 gap-2">
        <View className="flex-row items-baseline justify-between gap-2">
          <Text className="text-base font-bold leading-none tracking-tight">{user?.displayName}</Text>
        </View>
      </View>
    </View>
  )
}
