import { router } from 'expo-router'
import { LucideBookOpen } from 'lucide-react-native'
import { Image, Pressable, View } from 'react-native'

import { useLastReadBook } from '@/modules/reader/use-last-read-book'

import { Icon } from '@/components/ui/icon'
import { Progress } from '@/components/ui/progress'
import { Text } from '@/components/ui/text'

export function ContinueReadingCard() {
  const lastRead = useLastReadBook()

  if (!lastRead) return null

  const { book, progress } = lastRead
  const percentage = Math.round(progress.percentage * 100)
  const coverUri = book.coverPath ? `file://${book.coverPath}` : undefined

  const handlePress = () => {
    router.push({ pathname: '/reader/[bookId]', params: { bookId: book.id } })
  }

  return (
    <View className="gap-3">
      <Text className="text-base font-bold text-foreground">Continue de onde parou</Text>

      <Pressable
        onPress={handlePress}
        className="flex-row gap-4 rounded-2xl border border-border/50 bg-secondary/40 p-4 active:opacity-70"
      >
        <View
          className="w-16 overflow-hidden rounded-xl border border-border/50 bg-secondary shadow-sm"
          style={{ aspectRatio: 2 / 3 }}
        >
          {coverUri ? (
            <Image source={{ uri: coverUri }} className="h-full w-full" resizeMode="cover" />
          ) : (
            <View className="flex-1 items-center justify-center">
              <Icon as={LucideBookOpen} size={20} className="color-muted-foreground" />
            </View>
          )}
        </View>

        <View className="flex-1 justify-between gap-2">
          <View className="gap-0.5">
            <Text numberOfLines={2} className="text-sm font-bold leading-tight text-foreground">
              {book.title}
            </Text>
            <Text numberOfLines={1} className="text-xs font-medium uppercase tracking-tight text-muted-foreground">
              {book.author || 'Autor desconhecido'}
            </Text>
          </View>

          <View className="gap-1.5">
            <Progress value={Math.max(percentage, 0)} className="h-1.5" />
            <Text className="text-xs font-medium text-muted-foreground">
              {Math.max(percentage, 0)}% concluído · Pág. {progress.location} de {progress.totalLocations}
            </Text>
          </View>
        </View>
      </Pressable>
    </View>
  )
}
