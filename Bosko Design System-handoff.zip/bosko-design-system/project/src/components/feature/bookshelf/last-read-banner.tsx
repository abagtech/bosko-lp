import { router } from 'expo-router'
import { LucideArrowRight, LucideBookOpen } from 'lucide-react-native'
import { Image, Pressable, View } from 'react-native'

import { useLastReadBook } from '@/modules/reader/use-last-read-book'

import { Icon } from '@/components/ui/icon'
import { Progress } from '@/components/ui/progress'
import { Text } from '@/components/ui/text'

export function LastReadBanner() {
  const lastRead = useLastReadBook()

  if (!lastRead) return null

  const { book, progress } = lastRead
  const percentage = Math.round((progress.percentage ?? 0) * 100)
  const coverUri = book.coverPath ? `file://${book.coverPath}` : undefined

  const handlePress = () => {
    router.push({ pathname: '/reader/[bookId]', params: { bookId: book.id } })
  }

  return (
    <View className="px-6 pb-5">
      <Pressable
        onPress={handlePress}
        className="flex-row items-center gap-3 rounded-2xl border border-border/50 bg-secondary/40 p-3 active:opacity-70"
      >
        <View
          className="w-10 overflow-hidden rounded-lg border border-border/50 bg-secondary"
          style={{ aspectRatio: 2 / 3 }}
        >
          {coverUri ? (
            <Image source={{ uri: coverUri }} className="h-full w-full" resizeMode="cover" />
          ) : (
            <View className="flex-1 items-center justify-center">
              <Icon as={LucideBookOpen} size={14} className="color-muted-foreground" />
            </View>
          )}
        </View>

        <View className="flex-1 gap-1.5">
          <Text numberOfLines={1} className="text-sm font-bold leading-none text-foreground">
            {book.title}
          </Text>
          <Progress value={Math.max(percentage, 0)} className="h-1" />
          <Text className="text-xs font-medium text-muted-foreground">{Math.max(percentage, 0)}% concluído</Text>
        </View>

        <View className="h-9 w-9 items-center justify-center rounded-full bg-primary">
          <Icon as={LucideArrowRight} size={16} className="color-primary-foreground" />
        </View>
      </Pressable>
    </View>
  )
}
