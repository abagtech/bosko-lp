import { View, Pressable } from 'react-native'

import { cn } from '@/components/lib/utils'
import { Text } from '@/components/ui/text'

type TabType = 'READING' | 'TO_READ' | 'READ'
const FILTERS: TabType[] = ['READING', 'TO_READ', 'READ']

export function BookshelfTabs({ active, onChange }: { active: TabType; onChange: (t: TabType) => void }) {
  return (
    <View className="flex-row gap-8 border-b border-border px-6">
      {FILTERS.map(tab => {
        const isActive = active === tab
        return (
          <Pressable
            key={tab}
            onPress={() => onChange(tab)}
            className={cn([`pb-4`, isActive && 'border-b-2 border-primary'])}
          >
            <Text className={cn(`text-lg font-bold text-muted-foreground`, isActive && 'text-foreground')}>
              {tab === 'READING' && 'Lendo'}
              {tab === 'TO_READ' && 'Para Ler'}
              {tab === 'READ' && 'Lidos'}
            </Text>
          </Pressable>
        )
      })}
    </View>
  )
}
