import { useRouter } from 'expo-router'
import { BookOpen, BookPlus, Trophy } from 'lucide-react-native'
import { View } from 'react-native'

import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icon'
import { Text } from '@/components/ui/text'

type TabType = 'TO_READ' | 'READING' | 'READ'

interface EmptyStateProps {
  activeTab: TabType
  changeTab?: (tab: TabType) => void
}

export function BookshelfEmptyState({ activeTab, changeTab }: EmptyStateProps) {
  const router = useRouter()

  const config = {
    TO_READ: {
      Icon: BookPlus,
      title: 'Sua estante está vazia',
      description: 'Adicione livros no formato EPUB para encontrá-los aqui.',
      buttonLabel: 'Adicionar livro',
      onPress: () => router.push('/local-books/add'),
    },
    READING: {
      Icon: BookOpen,
      title: 'Nenhuma leitura ativa',
      description: 'Parece que você não começou nenhum livro recentemente. Que tal um novo capítulo?',
      buttonLabel: 'Ir para minha estante',
      onPress: () => changeTab && changeTab('TO_READ'),
    },
    READ: {
      Icon: Trophy,
      title: 'Nenhum livro concluído',
      description: 'Suas leituras finalizadas aparecerão aqui para você celebrar suas conquistas.',
      buttonLabel: 'Ver o que estou lendo',
      onPress: () => changeTab && changeTab('READING'),
    },
  }

  const current = config[activeTab]
  const currentIcon = current.Icon

  return (
    <View className="flex-1 items-center justify-center gap-6 px-10 py-20">
      <View className="rounded-full bg-muted p-8">
        <Icon as={currentIcon} size={48} className="text-primary" />
      </View>

      <View className="items-center gap-2">
        <Text className="text-center text-xl font-bold">{current.title}</Text>
        <Text className="text-center leading-relaxed text-muted-foreground">{current.description}</Text>
      </View>

      <Button onPress={current.onPress}>
        <Text>{current.buttonLabel}</Text>
      </Button>
    </View>
  )
}
