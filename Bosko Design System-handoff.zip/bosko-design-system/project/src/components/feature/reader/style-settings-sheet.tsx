import {
  LucideAlignJustify,
  LucideAlignLeft,
  LucideCoffee,
  LucideMinus,
  LucideMoon,
  LucidePlus,
  LucideSun,
} from 'lucide-react-native'
import { MotiView } from 'moti'
import { useEffect, useMemo, useState } from 'react'
import { ScrollView, View } from 'react-native'
import WebView from 'react-native-webview'

import { background, onBackground } from '@/core/reader/epub-theme'
import { ReaderSettings, useReaderSettingsStore } from '@/core/store/reader-settings-store'
import { useReaderUIStore } from '@/core/store/reader-ui-store'
import { ReaderFonts, ReaderFontsValues } from '@/core/store/types'

import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icon'
import { Text } from '@/components/ui/text'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'

const MIN_FONT_SIZE = 12
const MAX_FONT_SIZE = 36

const LINE_HEIGHTS = [
  { label: 'PP', value: '1.2' },
  { label: 'P', value: '1.4' },
  { label: 'M', value: '1.6' },
  { label: 'G', value: '1.8' },
  { label: 'GG', value: '2.0' },
]

const generatePreviewHtml = (s: ReaderSettings) => `
  <!DOCTYPE html>
  <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
      <style>
        body {
          background-color: ${background[s.theme]};
          color: ${onBackground[s.theme]};
          font-family: ${s.fontFamily};
          font-size: ${s.fontSize}px;
          line-height: ${s.lineHeight};
          text-align: ${s.textAlign};
          margin: 0;
          padding: 16px;
          overflow: hidden;
        }
        p { margin: 0; padding: 0; width: 100%; }
      </style>
    </head>
    <body>
      <p>Esse é um texto de exemplo para a pré-visualização do tema no leitor.</p>
    </body>
  </html>
`

export function StyleSettingsSheet() {
  const { settings, update } = useReaderSettingsStore()
  const isOpen = useReaderUIStore(s => s.isStyleSettingsOpen)
  const onClose = useReaderUIStore(s => s.closeStyleSettings)

  const [temp, setTemp] = useState<ReaderSettings>(settings)

  useEffect(() => {
    if (isOpen) setTemp(settings)
  }, [isOpen])

  const handleApply = () => {
    update(temp)
    onClose()
  }

  const handleCancel = () => {
    setTemp(settings)
    onClose()
  }

  const previewSource = useMemo(() => ({ html: generatePreviewHtml(temp) }), [temp])

  if (!isOpen) return null

  return (
    <MotiView
      className="flex-1 rounded-t-3xl border-t border-border bg-background shadow-2xl"
      from={{ translateY: 1000 }}
      animate={{ translateY: isOpen ? 0 : 1000 }}
      transition={{ type: 'timing', duration: 300 }}
      pointerEvents={isOpen ? 'auto' : 'none'}
    >
      {/* ── Título ── */}
      <View className="items-center border-b border-border p-4">
        <Text className="text-lg font-bold uppercase tracking-widest">Opções de Estilo</Text>
      </View>

      {/* ── Prévia ── */}
      <View className="border-b border-border bg-background p-6">
        <Text className="mb-3 text-xs font-bold uppercase tracking-widest text-muted-foreground">Prévia</Text>
        <View className="h-28 overflow-hidden rounded-3xl border border-border">
          <WebView
            originWhitelist={['*']}
            source={previewSource}
            scrollEnabled={false}
            style={{ backgroundColor: background[temp.theme] }}
            pointerEvents="none"
          />
        </View>
      </View>

      {/* ── Controles ── */}
      <ScrollView className="flex-1" contentContainerClassName="p-6 gap-8">
        {/* Tema */}
        <View className="gap-4">
          <Text className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Tema</Text>
          <ToggleGroup
            value={temp.theme}
            onValueChange={val => val && setTemp(s => ({ ...s, theme: val as ReaderSettings['theme'] }))}
            type="single"
            className="flex-row rounded-xl bg-secondary/20 p-1"
          >
            <ToggleGroupItem value="light" className="flex-1 flex-row gap-2 py-3">
              <Icon as={LucideSun} size={18} />
              <Text>Claro</Text>
            </ToggleGroupItem>
            <ToggleGroupItem value="dark" className="flex-1 flex-row gap-2 py-3">
              <Icon as={LucideMoon} size={18} />
              <Text>Escuro</Text>
            </ToggleGroupItem>
            <ToggleGroupItem value="sepia" className="flex-1 flex-row gap-2 py-3">
              <Icon as={LucideCoffee} size={18} />
              <Text>Sépia</Text>
            </ToggleGroupItem>
          </ToggleGroup>
        </View>

        {/* Tipografia */}
        <View className="gap-4">
          <Text className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Tipografia</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <ToggleGroup
              value={temp.fontFamily}
              onValueChange={val => val && setTemp(s => ({ ...s, fontFamily: val as ReaderSettings['fontFamily'] }))}
              type="single"
              className="flex-row gap-2 rounded-xl bg-secondary/20 p-1"
            >
              {ReaderFonts.map(font => (
                <ToggleGroupItem key={font} value={font} className="rounded-lg px-6 py-3">
                  <Text style={{ fontFamily: font.split(',')[0].trim() }}>{ReaderFontsValues[font]}</Text>
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
          </ScrollView>
        </View>

        {/* Alinhamento */}
        <View className="gap-4">
          <Text className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Alinhamento</Text>
          <ToggleGroup
            value={temp.textAlign}
            onValueChange={val => val && setTemp(s => ({ ...s, textAlign: val as ReaderSettings['textAlign'] }))}
            type="single"
            className="flex-row rounded-xl bg-secondary/20 p-1"
          >
            <ToggleGroupItem value="left" className="flex-1 rounded-lg py-3">
              <Icon as={LucideAlignLeft} size={20} />
            </ToggleGroupItem>
            <ToggleGroupItem value="justify" className="flex-1 rounded-lg py-3">
              <Icon as={LucideAlignJustify} size={20} />
            </ToggleGroupItem>
          </ToggleGroup>
        </View>

        {/* Tamanho da fonte */}
        <View className="gap-4">
          <Text className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Tamanho</Text>
          <View className="flex-row items-center justify-between rounded-2xl bg-secondary/20 p-2">
            <Button
              variant="ghost"
              size="icon"
              disabled={temp.fontSize <= MIN_FONT_SIZE}
              onPress={() => setTemp(s => ({ ...s, fontSize: Math.max(MIN_FONT_SIZE, s.fontSize - 1) }))}
            >
              <Icon as={LucideMinus} size={20} className={temp.fontSize <= MIN_FONT_SIZE ? 'opacity-20' : ''} />
            </Button>

            <Text className="font-bold">{temp.fontSize}</Text>

            <Button
              variant="ghost"
              size="icon"
              disabled={temp.fontSize >= MAX_FONT_SIZE}
              onPress={() => setTemp(s => ({ ...s, fontSize: Math.min(MAX_FONT_SIZE, s.fontSize + 1) }))}
            >
              <Icon as={LucidePlus} size={20} className={temp.fontSize >= MAX_FONT_SIZE ? 'opacity-20' : ''} />
            </Button>
          </View>
        </View>

        {/* Espaçamento entre linhas */}
        <View className="gap-4 pb-12">
          <Text className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Espaçamento</Text>
          <ToggleGroup
            value={temp.lineHeight}
            onValueChange={val => val && setTemp(s => ({ ...s, lineHeight: val }))}
            type="single"
            className="flex-row rounded-xl bg-secondary/20 p-1"
          >
            {LINE_HEIGHTS.map(item => (
              <ToggleGroupItem key={item.value} value={item.value} className="flex-1 rounded-lg py-3">
                <Text className="font-bold">{item.label}</Text>
              </ToggleGroupItem>
            ))}
          </ToggleGroup>
        </View>
      </ScrollView>

      {/* ── Rodapé ── */}
      <View className="flex-row gap-4 border-t border-border bg-background p-6">
        <Button variant="secondary" className="flex-1 rounded-2xl" onPress={handleCancel}>
          <Text className="font-bold">Cancelar</Text>
        </Button>
        <Button className="flex-[2] rounded-2xl shadow-sm" onPress={handleApply}>
          <Text className="font-bold">Salvar Ajustes</Text>
        </Button>
      </View>
    </MotiView>
  )
}
