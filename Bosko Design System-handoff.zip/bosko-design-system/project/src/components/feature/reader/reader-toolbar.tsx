import { useRouter } from 'expo-router'
import { ChevronLeft, LucideList, LucideLightbulb, LucideType } from 'lucide-react-native'
import { MotiView } from 'moti'
import { useMemo } from 'react'
import { View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'

import { background, onBackground } from '@/core/reader/epub-theme'
import { useReaderProgressStore } from '@/core/store/reader-progress-store'
import { useReaderSettingsStore } from '@/core/store/reader-settings-store'

import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icon'
import { Text } from '@/components/ui/text'

interface ActionButtonsProps {
  onPressStyle: () => void
  onPressToc: () => void
  onPressHighlights: () => void
  onPressAlwaysOn: () => void
  fgColor: string
}

interface Props extends Omit<ActionButtonsProps, 'fgColor'> {
  title: string
  visible: boolean
}

export function ReaderToolbar({ title, visible, ...actions }: Props) {
  const insets = useSafeAreaInsets()
  const router = useRouter()

  const { percentage, currentLocation, totalLocations } = useReaderProgressStore()
  const { settings } = useReaderSettingsStore()

  const bgColor = background[settings.theme]
  const fgColor = onBackground[settings.theme]

  const progressLabel = useMemo(() => {
    // percentage vem como 0–1 do epub.js
    const percent = Math.round(percentage * 100)
    if (percent === 0 && currentLocation === 0) return null
    return `${percent}% — ${currentLocation} / ${totalLocations}`
  }, [percentage, currentLocation, totalLocations])

  return (
    <>
      <MotiView
        animate={{ opacity: visible ? 0.35 : 0 }}
        transition={{ type: 'timing', duration: 250 }}
        className="absolute inset-0 bg-black"
        pointerEvents="none"
      />

      <MotiView
        animate={{
          opacity: visible ? 1 : 0,
          translateY: visible ? 0 : -40,
        }}
        transition={{ type: 'timing', duration: 200 }}
        style={{ paddingTop: insets.top, backgroundColor: bgColor + 'E6' }}
        className="absolute inset-x-0 top-0"
        pointerEvents={visible ? 'auto' : 'none'}
      >
        <View className="h-16 flex-row items-center justify-between px-4">
          <HeaderBackButton onPress={() => router.back()} fgColor={fgColor} />

          <View className="flex-1 items-center px-4">
            <Text numberOfLines={1} style={{ color: fgColor }} className="text-base font-semibold">
              {title}
            </Text>
            {progressLabel && (
              <Text style={{ color: fgColor + 'B3' }} className="text-xs">
                {progressLabel}
              </Text>
            )}
          </View>

          <ActionButtons {...actions} fgColor={fgColor} />
        </View>
      </MotiView>
    </>
  )
}

const ActionButtons = ({ onPressStyle, onPressToc, onPressAlwaysOn, fgColor }: ActionButtonsProps) => (
  <View className="flex-row items-center gap-2">
    <Button variant="ghost" size="icon" onPress={onPressStyle}>
      <Icon as={LucideType} size={20} color={fgColor} />
    </Button>
    <Button variant="ghost" size="icon" onPress={onPressToc}>
      <Icon as={LucideList} size={20} color={fgColor} />
    </Button>
    <Button variant="ghost" size="icon" onPress={onPressAlwaysOn}>
      <Icon as={LucideLightbulb} size={20} color={fgColor} />
    </Button>
  </View>
)

const HeaderBackButton = ({ onPress, fgColor }: { onPress: () => void; fgColor: string }) => (
  <Button variant="ghost" size="icon" onPress={onPress}>
    <Icon as={ChevronLeft} size={22} color={fgColor} />
  </Button>
)
