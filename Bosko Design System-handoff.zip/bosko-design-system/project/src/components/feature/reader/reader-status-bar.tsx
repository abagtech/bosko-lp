import * as NavigationBar from 'expo-navigation-bar'
import { useNavigation } from 'expo-router'
import { StatusBar } from 'expo-status-bar'
import { useEffect } from 'react'
import { Platform } from 'react-native'

import { useReaderSettingsStore } from '@/core/store/reader-settings-store'
import { useReaderUIStore } from '@/core/store/reader-ui-store'

export const ReaderStatusBar = () => {
  const navigation = useNavigation()
  const isSettingsOpen = useReaderUIStore(s => s.isSettingsOpen)
  const { settings } = useReaderSettingsStore()

  useEffect(() => {
    navigation.setOptions({ headerShown: false })

    if (Platform.OS === 'android') {
      NavigationBar.setVisibilityAsync(isSettingsOpen ? 'visible' : 'hidden')
      NavigationBar.setBehaviorAsync('overlay-swipe')
    }
  }, [isSettingsOpen])

  useEffect(() => {
    return () => {
      if (Platform.OS === 'android') {
        NavigationBar.setVisibilityAsync('visible')
      }
    }
  }, [])

  return <StatusBar hidden={!isSettingsOpen} style={settings.theme === 'dark' ? 'light' : 'dark'} />
}
