import { MotiView } from 'moti'
import { View } from 'react-native'

import { useReaderProgressStore } from '@/core/store/reader-progress-store'
import { useReaderSettingsStore } from '@/core/store/reader-settings-store'

const TRACK_COLOR = {
  light: 'rgba(0,0,0,0.08)',
  dark: 'rgba(255,255,255,0.12)',
  sepia: 'rgba(0,0,0,0.10)',
} as const

const PROGRESS_COLOR = {
  light: '#b24a09',
  dark: '#f97316',
  sepia: '#c57a05',
} as const

export function ReaderProgressBar() {
  const percentage = useReaderProgressStore(s => s.percentage)
  const theme = useReaderSettingsStore(s => s.settings.theme)

  // percentage vem do epub.js como 0–1 (ex: 0.42 = 42%)
  const widthPercent: `${number}%` = `${Math.min(percentage * 100, 100)}%`

  return (
    <View className="pb-safe -z-10">
      <View className="h-1 w-full" style={{ backgroundColor: TRACK_COLOR[theme] }}>
        <MotiView
          animate={{ width: widthPercent }}
          transition={{ type: 'timing', duration: 150 }}
          className="h-1"
          style={{ backgroundColor: PROGRESS_COLOR[theme] }}
        />
      </View>
    </View>
  )
}
