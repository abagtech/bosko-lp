import { useColorScheme } from 'nativewind'
import Svg, { Path } from 'react-native-svg'

import { THEME } from '@/components/lib/theme'

export const LogoImage = ({ width = 220, height = 80 }: { width?: number; height?: number }) => {
  const { colorScheme } = useColorScheme()
  const theme = THEME[colorScheme ?? 'light']

  return (
    <Svg width={width} height={height} viewBox="0 0 412 412">
      <Path
        d="M.29 411.72a204.822 204.822 0 0027.52-102.86A204.65 204.65 0 00.29 206.01a204.78 204.78 0 0027.52-102.85A204.79 204.79 0 00.29.31h126.76a204.694 204.694 0 0127.53 102.86 204.804 204.804 0 01-27.52 102.85 204.715 204.715 0 0127.53 102.86 204.82 204.82 0 01-27.52 102.86L.29 411.72z"
        fill={theme.foreground}
      />
      <Path
        d="M257.43 411.72A332.87 332.87 0 00186.66 206 332.796 332.796 0 00257.43.31h154.29A332.86 332.86 0 01340.93 206a332.885 332.885 0 0170.77 205.72H257.43z"
        fill={theme.primary}
      />
    </Svg>
  )
}
