---
name: bosko-design
description: Use this skill to generate well-branded interfaces and assets for Bosko, the gamified Brazilian e-book reader, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation
- **Brand:** Bosko is a gamified Brazilian e-book reader. Brazilian Portuguese only in product copy.
- **Palette:** Black `#000`, piercing orange `#FF6900`, white `#FFFFFF`. That's the whole brand. Warm cream + dark stone secondary palettes exist for product surfaces.
- **Type:** Inter (product UI, body, hero), Hind Bold (marketing display only).
- **Mark:** wave-`B` (black) + wave-`K` (orange) — `assets/bosko-mark-duo.svg`. Don't redraw it.
- **No emoji, no gradients, no glassmorphism, no decorative illustration.**

## How to use
1. Drop `colors_and_type.css` into your page `<head>`. It defines both light and dark themes via shadcn-style HSL variables — add `class="dark"` to `<body>` for dark mode.
2. Use `assets/bosko-mark-duo.svg` (or `-black/-white/-orange`) for the icon, `bosko-logo-horizontal.svg` for the wordmark.
3. Patterns: see `ui_kits/mobile-app/` for component code (buttons, cards, inputs, tabs, FAB, badges) — copy and translate to your framework.
4. Marketing pieces: deep black background, single Hind Bold headline with one orange word, full-bleed wave shape, mark in top-left.
