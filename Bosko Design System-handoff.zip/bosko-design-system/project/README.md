# Bosko Design System (BDS)

A minimalist, high-contrast visual language for **Bosko** — a gamified Brazilian e-book reader that bridges public-domain classics and personal libraries under one distraction-free reading framework.

Built around a deep obsidian dark mode and a single piercing orange accent (**#FF6900**). Sharp small-radius corners, generous type scale, almost no chrome. Every pixel earns its place.

> **Locale note.** The product ships in Brazilian Portuguese. All product copy is `pt-BR`; engineering identifiers are English. Sample strings in this design system are pulled directly from the live app.

---

## Sources used to build this system

This design system was reconstructed from the following first-party materials. Open them if you have access — they are the ground truth.

| Source | What's in it |
| --- | --- |
| **Figma:** Bosko Design.fig | Logo lockups (icon / horizontal / vertical × 5 backgrounds), brand banners, QR-code patterns, visual identity wallpapers, marketing scroll mockup |
| **GitHub:** `abagtech/bosko-app` ([github.com/abagtech/bosko-app](https://github.com/abagtech/bosko-app)) | The mobile app source. React Native + Expo + NativeWind, shadcn `new-york` style, HSL CSS variables. Everything in `src/global.css`, `tailwind.config.js`, `src/components/ui/` and `src/components/feature/`. |
| **GitHub:** `abagtech/bosko-back` ([github.com/abagtech/bosko-back](https://github.com/abagtech/bosko-back)) | Backend (not visually relevant — referenced for completeness). |

If you're regenerating designs for Bosko, you'll get much better results if you re-explore these directly — especially `bosko-app/src/components/feature/` for screen-specific patterns this skill compresses.

---

## What Bosko actually is

A mobile-first **gamified e-book reader**. Users:

- Build a **bookshelf** ("Estante") split into _Para ler_ / _Lendo_ / _Lidos_
- Import their own EPUBs **or** browse a built-in public-domain library
- Read in a custom WebView reader with persistent style settings (font, line-height, theme)
- Track XP and levels for time read — exponential leveling system

Architecture: Expo Router, TanStack Query (server state), Zustand + MMKV (UI + persistent state), `@epubjs-react-native/core` for the reader, Moti + Reanimated for motion, Lucide for icons. Apps ship for iOS + Android; web build is metro-static.

---

## Visual Foundations

Bosko's identity is deliberately spartan: **black, white, one orange.** No gradients on UI, no decorative illustration, no rounded blobs. The system gets its energy from scale (huge type), negative space, and a single saturated color used as a knife.

### Color
- **Obsidian black** `#000000` — the canonical brand background. Used 940× in the Figma file. Treat dark mode as the *default* identity even though the app launches in warm-light by default for accessibility.
- **Piercing orange** `#FF6900` — the only accent. Use it for CTAs, the "K" of the wordmark, focus rings, level-up moments, and exactly nothing else. Never tint it; never gradient it.
- **Warm cream** family — the light-mode product palette (`hsl(40 60% 98%)` background, sand borders, warm card surface). This is the *reading* environment, deliberately paper-coloured to reduce eye strain.
- **Dark stone** family — the dark-mode product palette built on `hsl(24 9.8% 10%)`. Warmer than true black; uses true black only for marketing.
- Destructive is a deep brick red — never use orange for "danger".

### Typography
- **Inter** (Medium/Semi Bold/Bold) — product UI, hero headlines, body. The figma's largest text ("Pronto para sua próxima história?") is Inter Medium 104px.
- **Hind Bold** — marketing display only. The banner shout-lines ("Levando sua leitura para outro nível") are Hind Bold 96-100px. Used for big tactile statements where Inter feels too neutral.
- **Inter Bold uppercase + 8px tracking** — the loud CTA pill ("BAIXAR BOSKO"). Reserved for marketing.
- No serif anywhere. The reader itself lets the *user* pick serif/sans for their content.

### Backgrounds & motifs
- **Wave shapes.** The brand mark is a stylized `}( ` — two facing parentheses. That wave gets blown up into hero backgrounds: a giant orange arc bleeding off the canvas, a black arc bleeding in from the opposite corner. See `Banner` in the Figma.
- **No textures, grain, or noise.** Flat fills only. The K-pattern wallpaper (`PatternK_Laranja`) is the only repeating motif and it's just the wave shape tiled.
- **No photography.** App + marketing rely on book-cover artwork (user-supplied) as the only "imagery".
- **QR codes** appear in marketing with the brand mark embedded center — the K-shape replaces the conventional QR centerpiece.

### Borders & corners
- **Small radii.** `--radius: 0.3rem` (≈4.8px). Cards, inputs, buttons all sit at lg/md (4-5px). The only pill-shape is the marketing CTA and the bookshelf FAB.
- **1px borders** on inputs and cards. `hairline` borders on subtle separators (RN-specific token).
- Borders use the warm sand color on light, warm-stone on dark — never pure black on light.

### Shadows & elevation
- Almost everything is `shadow-sm shadow-black/5` — a barely-there 1px drop. Marketing is flat.
- The FAB ("+" on bookshelf) gets `shadow-md`. No floating cards beyond that.
- Focus rings: 3px ring at 50% opacity of the ring color (orange).

### Animation
- **Moti + Reanimated** for stateful motion. Style is *snappy and short* — 150–250ms, ease-out. No bounces, no spring overshoot on UI.
- Accordion content uses `accordion-down 0.2s ease-out`.
- Page transitions: native (Expo Router defaults). Reader uses programmatic page-flip from epub.js.
- Marketing uses no animation — it's print-style still imagery.

### Hover / press / focus
- **Hover** (web only): `bg-primary/90` — 10% darker on the primary color. Outline buttons fill in to accent.
- **Press** (mobile): `active:bg-primary/90` — same 90% opacity treatment. No scale-down, no haptic-mimicking shrink.
- **Disabled**: `opacity-50`. No special color.
- **Focus** (web): 3px ring of `ring/50` at 3px offset. Visible on tab nav.

### Transparency / blur
- Used sparingly. The reader toolbar uses semi-transparent black overlays for ephemeral controls; the rest of the app is opaque.
- No glassmorphism. No backdrop-filter chrome.

### Layout rules
- Fixed bottom-tab nav on the main app (`(tabs)/_layout.tsx`). FAB anchored bottom-right at `bottom-6 right-6`.
- Default page padding is **24px** (`p-6`). Forms gap 8px between fields, 32px between sections.
- Marketing uses a horizontally-scrolling 12,900×2,796 "scroll" composition — each card is a phone in context with a single headline above. The format is intentional: no traditional sections.

---

## Content Fundamentals

> **All product copy is Brazilian Portuguese**, written warm, direct, and slightly emotional. Never corporate, never twee.

### Voice
- **You-form (você), informal**. No "vosso" or business-formal constructions. Sentences are short and human.
- **Present tense + active verbs.** "Entre para continuar sua jornada de leitura." Not "É possível continuar…"
- Compound verbs are kept simple; no participle gymnastics.

### Tone examples (from the live app)
- Welcome: **"Bem-vindo de volta"** + **"Entre para continuar sua jornada de leitura."**
- Marketing hero: **"Levando sua leitura para outro nível"** — the word **"outro nível"** sits in orange, the rest in white. A promise, not a feature.
- CTA: **"BAIXAR BOSKO"** — uppercased, wide-tracked. The only place uppercase is used.
- Sub-CTA: **"Pronto para sua próxima história?"** — pure invitation. Question + emotional verb.
- Auth nudge: **"Ainda não tem uma conta?" "Cadastre-se"** — never "Sign up", always full verb.
- Error: **"Não foi possível fazer login. Verifique suas credenciais e tente novamente."** — apology + concrete next step.
- Empty state, marketing micro-copy: **"Vários clássicos na palma da sua mão"**, **"Adicione na estante comece a ler agora"**, **"A liberdade de ler seus próprios livros"** — concrete benefits, no buzzwords.

### Casing rules
- **Sentence case** everywhere except for the one shouty CTA. Even feature names: "Estante", "Perfil", "Configurações".
- **Section titles in nav** are single Portuguese nouns: *Estante / Perfil*.
- Buttons: imperative verbs in sentence case: "Acessar Conta", "Cadastre-se", "Adicionar livro".

### What we don't do
- **No emoji.** Anywhere. The brand has zero appetite for them; reading is sacred.
- **No exclamation marks** except in error/celebration. Statements end with periods.
- **No "AI", "powered by", "next-gen"** filler.
- **No translation calques.** Don't translate English idioms; write in native Brazilian Portuguese.
- **No abbreviations** in user-facing copy. "Configurações", not "Config".

---

## Iconography

- **Lucide React Native** is the icon library (`lucide-react-native`). All product icons.
- **Stroke style:** 1.5–2px stroke, no fill, rounded line-cap. The Lucide default.
- **Sizes:** 16 / 20 / 24 px. The bookshelf FAB uses 24, inline icons use 16-20.
- **Color:** Icons inherit `currentColor` — usually `text-foreground` or `text-muted-foreground`. The eye/eye-off password toggle is exactly this pattern.
- **No icon fonts.** No Material Symbols. No FontAwesome.
- **No emoji** as icons or decoration. Bosko explicitly avoids them.
- **No unicode chars** (•, →, ★) as substitutes — use the Lucide equivalent (Dot, ArrowRight, Star).

The brand mark itself is a **bespoke pictogram** — a wave-`B` paired with a wave-`K`. It is the *only* hand-drawn glyph in the system; reuse the supplied SVG, never approximate it with characters.

Files in `assets/`:
- `bosko-mark-duo.svg` — primary mark, black B + orange K. **Default.**
- `bosko-mark-black.svg`, `bosko-mark-white.svg`, `bosko-mark-orange.svg` — monochrome variants
- `bosko-logo-horizontal.svg` — mark + "bosko" wordmark
- `icon.png`, `adaptive-icon.png`, `splash.png`, `favicon.png` — app store / OS assets straight from the codebase

---

## Index

```
README.md                ← you are here
SKILL.md                 ← agent-skill front matter (downloadable)
colors_and_type.css      ← drop-in CSS variables (light + dark themes)
assets/                  ← logos, app icons, raw vector exports, simulator screenshots
preview/                 ← design-system cards rendered into the project tab
site/
  ├─ index.html          ← marketing landing page with CTA + App Store badges
  ├─ privacy.html        ← LGPD-aligned Política de Privacidade
  └─ support.html        ← Central de ajuda (FAQ + contact)
src/                     ← imported source from abagtech/bosko-app (reference)
```

The three pages under `site/` are intended for App Store / Play Store submission:
- **Marketing URL** → `site/index.html`
- **Support URL** → `site/support.html`
- **Privacy Policy URL** → `site/privacy.html`

---

## Caveats & substitutions

- **Inter and Hind** are loaded from Google Fonts CDN. The brand assets reference these exact families and weights — Google's webfont is the same source. No `.ttf` files copied locally.
- The full horizontal wordmark in `assets/bosko-logo-horizontal-*.{svg,png}` was provided by the brand owner; the standalone `bosko-mark-*.svg` files use the icon-only portion (B + K shapes).
- App Store / Play Store badges on the landing page are simplified custom drawings, not the official Apple/Google asset bundles. Replace with the official badges before App Store submission.
- The mobile UI kit (a click-thru web recreation of the in-app screens) was started and then deprioritized at the user's request — see the simulator screenshots in `assets/screenshots/` if you need to see the real app.
